<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>To-Do List</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<?php $index = 0;?>
    <div class="slider" id="slider">
  
        <ul class="task-list" id="taskList">
            <?php foreach ($tasks as $task): ?>
                <?php echo  $index+1 ?>
                <li class="task-item" data-id="<?php echo $task['id']; ?>">
                    <?php echo htmlspecialchars($task['title']); ?>
                    <a href="admin.php?action=show_edit_form&id=<?php echo $task['id']; ?>">Edit</a>
                    <a href="admin.php?action=delete&id=<?php echo $task['id']; ?>">BORRAR</a>
                </li>
                <?php $index++;?>
            <?php endforeach; ?>
        </ul>
        
    </div>
    <div class="active-task">
        <input type="text" id="activeTask" readonly>
    </div>
 
    <div>
        <a href="admin.php?action=show_add_form">NUEVA TAREA</a>
    </div>
    <script src="slider.js"></script>
</body>
</html>
