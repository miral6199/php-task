document.addEventListener("DOMContentLoaded", function() {
    const taskList = document.getElementById("taskList");
    const activeTask = document.getElementById("activeTask");

    const tasks = taskList.getElementsByClassName("task-item");
    const taskHeight = 50; 
    let currentTaskIndex = 0;
    let interval;

    function updateUI() {
        const topPosition = -currentTaskIndex * taskHeight;
        taskList.style.top = `${topPosition}px`;

        if (tasks[currentTaskIndex]) {
            activeTask.value = tasks[currentTaskIndex].innerText.split('Edit')[0].trim();
        }
    }

    function startSlider() {
        interval = setInterval(function() {
            if (currentTaskIndex < tasks.length - 1) {
                currentTaskIndex++;
            } else {
                currentTaskIndex = 0;
            }
            updateUI();
        }, 2000);
    }

    function stopSlider() {
        clearInterval(interval);
    }

    for (let task of tasks) {
        task.addEventListener("click", stopSlider);
    }

    startSlider();
    updateUI();
});
