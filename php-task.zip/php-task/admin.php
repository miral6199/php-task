<?php
include 'controller.php';

$action = $_GET['action'] ?? 'list';

if ($action == 'add') {
    $title = $_POST['title'];
    addTask($title);
} elseif ($action == 'edit') {
    $id = $_POST['id'];
    $title = $_POST['title'];
    editTask($id, $title);
} elseif ($action == 'delete') {
    $id = $_GET['id'];
    deleteTask($id);
} elseif ($action == 'show_edit_form') {
    $id = $_GET['id'];
    $task = getTask($id);
    include 'template_edit.php';
    exit;
} elseif ($action == 'show_add_form') {
    include 'template_edit.php';
    exit;
}

$tasks = getTasks();
include 'template_list.php';
?>
