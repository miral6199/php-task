<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "php-task";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

function getTasks() {
    global $conn;
    $sql = "SELECT * FROM tasks ORDER BY id DESC";
    $result = $conn->query($sql);

    $tasks = [];
    while($row = $result->fetch_assoc()) {
        $tasks[] = $row;
    }
    return $tasks;
}

function addTask($title) {
    global $conn;
    $stmt = $conn->prepare("INSERT INTO tasks (title) VALUES (?)");
    $stmt->bind_param("s", $title);
    $stmt->execute();
    $stmt->close();
}

function getTask($id) {
    global $conn;
    $stmt = $conn->prepare("SELECT * FROM tasks WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    $task = $result->fetch_assoc();
    $stmt->close();
    return $task;
}

function editTask($id, $title) {
    global $conn;
    $stmt = $conn->prepare("UPDATE tasks SET title = ? WHERE id = ?");
    $stmt->bind_param("si", $title, $id);
    $stmt->execute();
    $stmt->close();
}

function deleteTask($id) {
    global $conn;
    $stmt = $conn->prepare("DELETE FROM tasks WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stmt->close();
}

// Close connection
// $conn->close();
?>



