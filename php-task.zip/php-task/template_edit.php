<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($task) ? 'EDITAR TAREA' : 'Add TAREA'; ?></title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <form action="admin.php?action=<?php echo isset($task) ? 'edit' : 'add'; ?>" method="POST">
        <?php if (isset($task)): ?>
            <input type="hidden" name="id" value="<?php echo $task['id']; ?>">
        <?php endif; ?>
        <label for="title">Task:</label>
        <input type="text" name="title" id="title" value="<?php echo isset($task) ? htmlspecialchars($task['title']) : ''; ?>">
        <button type="submit"><?php echo isset($task) ? 'EDITAR' : 'NUEVA'; ?>  TAREA</button>
    </form>
    <a href="admin.php">Back to list</a>
</body>
</html>
