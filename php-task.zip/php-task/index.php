


<?php include 'template_list.php'; ?>
<script src="slider.js"></script>